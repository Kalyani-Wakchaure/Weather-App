from flask import Flask, render_template, request
from flask_mysqldb import MySQL
import requests
from datetime import datetime

app = Flask(__name__)

# MySQL configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Cdac@2022'
app.config['MYSQL_DB'] = 'weather_app'

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/weather', methods=['POST'])
def weather():
    city = request.form['city']
    api_key = '7e5c7089fe7e335746ea44f7c7accb22'
    weather_url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric'
    response = requests.get(weather_url)
    data = response.json()

    if data['cod'] == '404':
        weather_data = {
            'city': city,
            'error': 'City not found!'
        }
    else:
        date = datetime.utcfromtimestamp(data['dt']).strftime('%Y-%m-%d %H:%M:%S')
        weather_data = {
            'city': data['name'],
            'temperature': data['main']['temp'],
            'humidity': data['main']['humidity'],
            'wind': data['wind']['speed'],
            'cloud': data['weather'][0]['description'],
            'date': date
        }

        # Insert weather data into MySQL
        try:
            cur = mysql.connection.cursor()
            insert_query = '''INSERT INTO weather (city, temperature, humidity, wind, cloud, date) 
                              VALUES (%s, %s, %s, %s, %s, %s)'''
            cur.execute(insert_query, (weather_data['city'], weather_data['temperature'], 
                                       weather_data['humidity'], weather_data['wind'], 
                                       weather_data['cloud'], weather_data['date']))
            mysql.connection.commit()
            cur.close()
        except Exception as e:
            print(f"Error: {e}")

    return render_template('weather.html', weather_data=weather_data)

if __name__ == '__main__':
    app.run(debug=True)
